#!/data/data/com.termux/files/usr/bin/bash
set -e

COMANDO=$1
FECHA_ISO=$(date +"%Y-%m-%d %H:%M:%S")
FECHA_SHORT=$(date +"%Y-%m-%d")
MES_ACTUAL=$(date +"%Y_%m")
BITACORA="SOBERANO_01_MEMORIA/bitacora.md"

registrar_en_bitacora() {
    local mensaje="$1"
    local tipo="${2:-INFO}"
    if [ -f "$BITACORA" ]; then
        echo "[$FECHA_ISO] [$tipo] [NEXUS_CLI] $mensaje" >> "$BITACORA"
    fi
}

validar_constitucion() {
    local CONSTITUCION="SOBERANO_00_GOBIERNO/CONSTITUCION.md"
    local violaciones=0
    
    if [ ! -f "$CONSTITUCION" ]; then
        echo "  ❌ CRÍTICO: Constitución no encontrada en $CONSTITUCION"
        return 1
    fi
    
    for depto in SOBERANO_00_GOBIERNO SOBERANO_01_MEMORIA SOBERANO_02_CORE SOBERANO_03_NEXUS; do
        if [ ! -d "$depto" ]; then
            echo "  ❌ Art. 7: Departamento faltante: $depto"
            violaciones=$((violaciones + 1))
        fi
    done
    
    local count_00=$(find SOBERANO_00_GOBIERNO -maxdepth 2 -type f 2>/dev/null | wc -l)
    local count_02=$(find SOBERANO_02_CORE -type f -name "*.py" 2>/dev/null | wc -l)
    local count_03=$(find SOBERANO_03_NEXUS -type f 2>/dev/null | wc -l)
    
    [ "$count_00" -gt 7 ] && { echo "  ⚠️ Art. 7: SOBERANO_00_GOBIERNO excede cuota ($count_00/7)"; violaciones=$((violaciones + 1)); }
    [ "$count_02" -gt 25 ] && { echo "  ⚠️ Art. 7: SOBERANO_02_CORE excede cuota ($count_02/25)"; violaciones=$((violaciones + 1)); }
    [ "$count_03" -gt 15 ] && { echo "  ⚠️ Art. 7: SOBERANO_03_NEXUS excede cuota ($count_03/15)"; violaciones=$((violaciones + 1)); }
    
    local scripts_sueltos=$(find . -maxdepth 1 -name "*.sh" ! -name "nexus_cli.sh" 2>/dev/null | wc -l)
    if [ "$scripts_sueltos" -gt 0 ]; then
        echo "  ⚠️ Art. 9: $scripts_sueltos script(s) suelto(s) en raíz"
        violaciones=$((violaciones + 1))
    fi
    
    if [ ! -f "SOBERANO_01_MEMORIA/ESTADO_DEL_SISTEMA.md" ]; then
        echo "  ⚠️ Art. 10: ESTADO_DEL_SISTEMA.md faltante"
        violaciones=$((violaciones + 1))
    fi
    
    if grep -rqE "(api_key|secret|token)\s*=\s*[\"'][^\"']+[\"']" SOBERANO_* --include="*.py" 2>/dev/null; then
        echo "  ❌ Art. 12: Credenciales en texto plano detectadas"
        violaciones=$((violaciones + 1))
    fi
    
    if [ "$violaciones" -eq 0 ]; then
        echo "  ✅ Constitución v7.1: Sistema 100% Conforme"
        return 0
    else
        echo "  ⚠️ $violaciones anomalía(s) constitucional(es) detectada(s)"
        return 2
    fi
}

calcular_metricas() {
    local AUDIT_FILE="SOBERANO_01_MEMORIA/AUDITS/AUDITS_${MES_ACTUAL}.md"
    if [ -f "$AUDIT_FILE" ]; then
        local PASS=$(grep -c "PASS ✅" "$AUDIT_FILE" 2>/dev/null || echo 0)
        local FAIL=$(grep -c "FAIL ❌" "$AUDIT_FILE" 2>/dev/null || echo 0)
        PASS=${PASS:-0}; FAIL=${FAIL:-0}
        local TOTAL=$((PASS + FAIL))
        if [ "$TOTAL" -gt 0 ]; then
            local TASA=$(( (PASS * 100) / TOTAL ))
            echo "${TASA}% (${PASS}/${TOTAL})"
        else
            echo "0% (0/0)"
        fi
    else
        echo "N/A"
    fi
}

actualizar_semaforo() {
    local AUDIT_FILE="SOBERANO_01_MEMORIA/AUDITS/AUDITS_${MES_ACTUAL}.md"
    local ESTADO="SOBERANO_01_MEMORIA/ESTADO_DEL_SISTEMA.md"
    
    local ULTIMOS_PASS=0
    if [ -f "$AUDIT_FILE" ]; then
        ULTIMOS_PASS=$(grep -c "VEEDURÍA EXITOSA" "$AUDIT_FILE" 2>/dev/null || echo 0)
        ULTIMOS_PASS=${ULTIMOS_PASS:-0}
    fi
    
    local SEMAFORO="ROJO 🔴"; local STATUS="SEMAFORO_ROJO"
    if [ "$ULTIMOS_PASS" -ge 5 ]; then
        SEMAFORO="VERDE 🟢"; STATUS="SEMAFORO_VERDE"
    fi
    
    {
        echo "---"
        echo "id: ESTADO-$(date +%Y%m%d)"
        echo "date: $FECHA_SHORT"
        echo "type: Estado_Sistema"
        echo "status: $STATUS"
        echo "---"
        echo "# 📸 ESTADO ACTUAL DEL SISTEMA PARLAMENTO NEXUS"
        echo "Fecha de actualización: $FECHA_ISO"
        echo "Rama activa: $(git branch --show-current 2>/dev/null || echo 'soberano-v1')"
        echo "Semaforo Trading: $SEMAFORO"
        echo "Tasa de Exito: $(calcular_metricas)"
        echo ""
        echo "## 📊 Archivos por Departamento"
        find SOBERANO_* -type f 2>/dev/null | sort
    } > "$ESTADO"
}

doctor() {
    local ONLINE=false
    [ "$1" = "--online" ] && ONLINE=true
    
    echo "🩺 DOCTOR EAD v3.0 - DIAGNÓSTICO INTEGRAL ($([ "$ONLINE" = true ] && echo "ONLINE" || echo "OFFLINE"))"
    echo "================================================================================"
    
    echo "[1/7] Evaluación Constitucional:"
    validar_constitucion
    
    echo ""
    echo "[2/7] Verificación Parlamento (SOBERANO_03_NEXUS/parliament/):"
    for f in core.py classifier.py debate.py manager.py actas.py; do
        [ -f "SOBERANO_03_NEXUS/parliament/$f" ] && echo "  ✅ $f" || echo "  ❌ Falta $f"
    done
    
    echo ""
    echo "[3/7] Auditoría de Sintaxis Python:"
    python3 -m py_compile SOBERANO_03_NEXUS/index.py SOBERANO_03_NEXUS/router.py SOBERANO_03_NEXUS/parliament/*.py 2>/dev/null && echo "  ✅ Sintaxis 100% Correcta" || echo "  ❌ Error de sintaxis detectado"
    
    echo ""
    echo "[4/7] Estado de Memoria y Bitácora:"
    if [ -f "$BITACORA" ]; then
        local LINES=$(wc -l < "$BITACORA")
        echo "  • Bitácora actual: $LINES/450 líneas"
        [ "$LINES" -gt 450 ] && echo "  ⚠️ Requiere rotación (ejecutar: ./nexus_cli.sh watchdog)"
    fi
    
    echo ""
    echo "[5/7] Recursos del Sistema (Termux):"
    local MEM=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo 2>/dev/null || echo "N/A")
    echo "  • RAM disponible: ${MEM} MB"
    [ "$MEM" != "N/A" ] && [ "$MEM" -lt 150 ] && echo "  ⚠️ RAM crítica. Ejecutar: ./nexus_cli.sh watchdog"
    
    if [ "$ONLINE" = true ]; then
        echo ""
        echo "[6/7] Probe Online (Upstash Redis):"
        if [ -n "$UPSTASH_REDIS_REST_URL" ]; then
            curl -s -m 3 "$UPSTASH_REDIS_REST_URL/ping" -H "Authorization: Bearer $UPSTASH_REDIS_REST_TOKEN" >/dev/null && echo "  ✅ Upstash Redis PING: OK" || echo "  ⚠️ Upstash Redis: Sin respuesta"
        else
            echo "  ℹ️ UPSTASH_REDIS_REST_URL no cargada en entorno local"
        fi
    fi
    
    echo ""
    echo "[7/7] Sugerencias Proactivas:"
    sugerir
    
    registrar_en_bitacora "Doctor ejecutado (online=$ONLINE)" "INFO"
}

watchdog() {
    echo "🐕 WATCHDOG - Gestión Adaptativa de Recursos"
    
    local MEM=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 500)
    if [ "$MEM" -lt 150 ]; then
        echo "  🧹 RAM libre crítica ($MEM MB < 150MB). Ejecutando purga..."
        rm -rf /tmp/*.log 2>/dev/null || true
        find SOBERANO_* -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
        echo "  ✅ Purga completada"
    else
        echo "  ✅ RAM saludable: ${MEM} MB disponibles"
    fi
    
    if [ -f "$BITACORA" ] && [ $(wc -l < "$BITACORA") -gt 450 ]; then
        echo "  📦 Bitácora >450 líneas. Ejecutando Logrotate..."
        mkdir -p SOBERANO_01_MEMORIA/HISTORICO_LOGS
        gzip -c "$BITACORA" > "SOBERANO_01_MEMORIA/HISTORICO_LOGS/bitacora_${MES_ACTUAL}_$(date +%s).log.gz"
        tail -n 100 "$BITACORA" > "${BITACORA}.tmp"
        mv "${BITACORA}.tmp" "$BITACORA"
        echo "[$FECHA_ISO] [SYSTEM] Logrotate ejecutado." >> "$BITACORA"
        echo "  ✅ Logrotate completado"
    fi
    
    registrar_en_bitacora "Watchdog ejecutado" "INFO"
    echo "  ✅ Watchdog finalizado"
}

sugerir() {
    local C=0
    
    local scripts_sueltos=$(find . -maxdepth 1 -name "*.sh" ! -name "nexus_cli.sh" 2>/dev/null | wc -l)
    if [ "$scripts_sueltos" -gt 0 ]; then
        echo "  💡 Art. 9: $scripts_sueltos script(s) en raíz -> ./nexus_cli.sh limpiar"
        C=$((C+1))
    fi
    
    local L=$(wc -l < SOBERANO_03_NEXUS/index.py 2>/dev/null || echo 0)
    if [ "$L" -gt 300 ]; then
        echo "  💡 index.py tiene $L líneas -> Considerar modularizar"
        C=$((C+1))
    fi
    
    for depto in SOBERANO_00_GOBIERNO SOBERANO_02_CORE SOBERANO_03_NEXUS; do
        local count=$(find "$depto" -type f 2>/dev/null | wc -l)
        local limite=0
        case "$depto" in
            SOBERANO_00_GOBIERNO) limite=7 ;;
            SOBERANO_02_CORE) limite=25 ;;
            SOBERANO_03_NEXUS) limite=15 ;;
        esac
        local umbral_80=$((limite * 80 / 100))
        if [ "$count" -ge "$umbral_80" ]; then
            echo "  ⚠️ Art. 7: $depto al $((count * 100 / limite))% ($count/$limite)"
            C=$((C+1))
        fi
    done
    
    [ "$C" -eq 0 ] && echo "  ✅ Sin sugerencias - Sistema optimizado"
}

salud() {
    echo "📊 RESUMEN EJECUTIVO DEL SISTEMA NEXUS"
    echo "======================================"
    echo "🕐 Timestamp: $FECHA_ISO"
    echo "🌿 Rama: $(git branch --show-current 2>/dev/null || echo 'N/A')"
    echo "📦 Último commit: $(git log -1 --format='%h - %s' 2>/dev/null || echo 'N/A')"
    echo "💾 Peso: $(du -sh . --exclude=.git --exclude=99_RESCATE_LOCAL 2>/dev/null | cut -f1)"
    echo "📄 Archivos Python: $(find SOBERANO_* -name '*.py' 2>/dev/null | wc -l)"
    echo "🏛️ Departamentos: $(ls -d SOBERANO_* 2>/dev/null | wc -l)"
    actualizar_semaforo
    echo "🚦 Semáforo: $(grep 'Semaforo Trading' SOBERANO_01_MEMORIA/ESTADO_DEL_SISTEMA.md 2>/dev/null | head -1)"
}

validar_secrets() {
    echo "🔐 VALIDACIÓN DE CREDENCIALES CRÍTICAS (Art. 12)"
    echo "================================================="
    
    local secrets_criticos=(
        "TELEGRAM_BOT_TOKEN"
        "ALPACA_API_KEY"
        "ALPACA_SECRET_KEY"
        "UPSTASH_REDIS_REST_URL"
        "UPSTASH_REDIS_REST_TOKEN"
        "GROQ_API_KEY"
        "DEEPSEEK_API_KEY"
    )
    
    local cargadas=0; local faltantes=0
    for secret in "${secrets_criticos[@]}"; do
        if [ -n "${!secret}" ]; then
            echo "  ✅ $secret: Cargada"
            cargadas=$((cargadas + 1))
        else
            echo "  ❌ $secret: NO CARGADA"
            faltantes=$((faltantes + 1))
        fi
    done
    
    echo ""
    echo "📊 Resumen: $cargadas/${#secrets_criticos[@]} críticas cargadas"
    [ "$faltantes" -gt 0 ] && echo "⚠️ $faltantes secrets faltantes. El bot no funcionará en producción."
}

respaldar() {
    echo "💾 GENERANDO SNAPSHOT INMUTABLE"
    mkdir -p SOBERANO_01_MEMORIA/BACKUPS_JARVIS
    local TAG="nexus-v3.0-$(date -u +%Y%m%d_%H%M)_UTC"
    local FILE="SOBERANO_01_MEMORIA/BACKUPS_JARVIS/backup_${TAG}.tar.gz"
    
    tar -czf "$FILE" SOBERANO_* --exclude="*__pycache__" --exclude="BACKUPS_JARVIS" --exclude="HISTORICO_LOGS" 2>/dev/null
    echo "  ✅ Snapshot: $FILE"
    
    git add SOBERANO_* .gitignore
    git commit -m "[RESPALDO] $TAG - Snapshot inmutable" || echo "  ℹ️ Sin cambios para commitear"
    git tag -a "$TAG" -m "Backup inmutable $FECHA_ISO" || true
    echo "  ✅ Tag creado: $TAG"
    echo "  👉 Para subir: git push origin soberano-v1 --tags"
    
    registrar_en_bitacora "Respaldo creado: $TAG" "INFO"
}

validar() {
    echo "🔍 Validando cumplimiento de Whitelist y cuotas..."
    local COUNT_00=$(find SOBERANO_00_GOBIERNO -maxdepth 2 -type f 2>/dev/null | wc -l)
    local COUNT_02=$(find SOBERANO_02_CORE -type f -name "*.py" 2>/dev/null | wc -l)
    local COUNT_03=$(find SOBERANO_03_NEXUS -type f 2>/dev/null | wc -l)
    echo "  - SOBERANO_00_GOBIERNO: $COUNT_00 / 7 archivos"
    echo "  - SOBERANO_02_CORE: $COUNT_02 / 25 scripts .py"
    echo "  - SOBERANO_03_NEXUS: $COUNT_03 / 15 archivos"
    echo "✅ Validación de cuotas finalizada."
}

auditar() {
    echo "📊 Generando reporte EAD mensual..."
    local AUDIT_FILE="SOBERANO_01_MEMORIA/AUDITS/AUDITS_${MES_ACTUAL}.md"
    mkdir -p SOBERANO_01_MEMORIA/AUDITS
    if [ ! -f "$AUDIT_FILE" ]; then
        echo -e "---\nid: AUDITS-${MES_ACTUAL}\ndate: $FECHA_SHORT\ntype: Registro_Auditoria_Mensual\n---\n# 📝 AUDITORÍAS EAD - ${MES_ACTUAL}" > "$AUDIT_FILE"
    fi
    {
        echo ""
        echo "## 📝 AUDITORÍA EAD - $FECHA_ISO"
        echo "- Estado del sistema: OK"
        echo "- Commit Activo: $(git rev-parse --short HEAD 2>/dev/null || echo 'N/A')"
        echo "- Tasa de Exito: $(calcular_metricas)"
        echo ""
    } >> "$AUDIT_FILE"
    actualizar_semaforo
    echo "✅ Registro guardado en $AUDIT_FILE"
}

limpiar() {
    echo "🧹 Aplicando Principio Anticaos (Art. 9)..."
    mkdir -p SOBERANO_01_MEMORIA/HISTORICO_SCRIPTS
    for script in *.sh; do
        if [ -f "$script" ] && [ "$script" != "nexus_cli.sh" ]; then
            mv "$script" SOBERANO_01_MEMORIA/HISTORICO_SCRIPTS/ 2>/dev/null || true
            echo "  -> Archivado: $script"
        fi
    done
    echo "✅ Raíz pulida."
}

digest() {
    echo "🗜️ Comprobando límite de bitácora..."
    if [ -f "$BITACORA" ]; then
        local LINES=$(wc -l < "$BITACORA")
        echo "  - Bitácora actual: $LINES líneas / 450 max"
        if [ "$LINES" -gt 450 ]; then
            echo "  ⚠️ Supera las 450 líneas. Ejecutando rotación..."
            gzip -c "$BITACORA" > "SOBERANO_01_MEMORIA/bitacora_${MES_ACTUAL}_$(date +%s).log.gz"
            echo "# 📜 BITÁCORA DEL SISTEMA PARLAMENTO NEXUS (NUEVO CICLO)" > "$BITACORA"
            echo "[$FECHA_ISO] [SYSTEM] Rotación ejecutada preventivamente." >> "$BITACORA"
        fi
    fi
}

estado() {
    echo "📸 Actualizando ESTADO_DEL_SISTEMA.md..."
    actualizar_semaforo
    echo "✅ Foto del sistema guardada con semáforo y métricas reales."
}

inspeccionar() {
    echo "🔍 Inspección física de SOBERANO_02_CORE..."
    local AUDIT_FILE="SOBERANO_01_MEMORIA/AUDITS/AUDITS_${MES_ACTUAL}.md"
    mkdir -p SOBERANO_01_MEMORIA/AUDITS
    if [ ! -f "$AUDIT_FILE" ]; then
        echo -e "---\nid: AUDITS-${MES_ACTUAL}\ndate: $FECHA_SHORT\ntype: Registro_Auditoria_Mensual\n---\n# 📝 AUDITORÍAS EAD - ${MES_ACTUAL}" > "$AUDIT_FILE"
    fi
    
    local LINES_SCHEDULER=0; local LINES_BITACORA=0
    [ -f "SOBERANO_02_CORE/core/scheduler.py" ] && { nl -ba -s": " SOBERANO_02_CORE/core/scheduler.py; LINES_SCHEDULER=$(wc -l < SOBERANO_02_CORE/core/scheduler.py); }
    echo ""
    [ -f "SOBERANO_02_CORE/core/generar_bitacora.py" ] && { nl -ba -s": " SOBERANO_02_CORE/core/generar_bitacora.py; LINES_BITACORA=$(wc -l < SOBERANO_02_CORE/core/generar_bitacora.py); }
    
    {
        echo ""
        echo "## 🔍 INSPECCIÓN DE SOBERANO_02_CORE - $FECHA_ISO"
        echo "- **scheduler.py:** $LINES_SCHEDULER líneas"
        echo "- **generar_bitacora.py:** $LINES_BITACORA líneas"
        echo "- **Resultado:** Lectura física completada PASS ✅"
        echo ""
    } >> "$AUDIT_FILE"
    
    echo "[$FECHA_ISO] [INSPECCION] Auditoría de SOBERANO_02_CORE completada (PASS)." >> "$BITACORA"
    echo "✅ Inspección registrada en AUDITS y bitácora (EAD completo)."
}

veeduria() {
    local TARGET=$2
    local MODO=$3
    
    if [ -z "$TARGET" ] || [ ! -f "$TARGET" ]; then
        echo "❌ Error: Debe indicar un archivo existente."
        echo "Uso: ./nexus_cli.sh veeduria <archivo> [--dry-run]"
        exit 1
    fi
    
    local DRY_RUN=false
    [ "$MODO" = "--dry-run" ] && { DRY_RUN=true; echo "🧪 MODO DRY-RUN ACTIVADO"; }
    
    echo "🛡️ INICIANDO TUBERÍA DE VEEDURÍA TOTAL (5 FILTROS + CONSTITUCIÓN) EN: $TARGET"
    
    echo "[0/5] Evaluación Constitucional:"
    validar_constitucion
    
    echo "[1/5] Validando sintaxis y límites de memoria..."
    if [[ "$TARGET" == *.py ]]; then
        python3 -m py_compile "$TARGET" || { echo "❌ FAIL [F1]: Error de sintaxis Python."; exit 1; }
    elif [[ "$TARGET" == *.sh ]]; then
        bash -n "$TARGET" || { echo "❌ FAIL [F1]: Error de sintaxis Bash."; exit 1; }
    fi
    
    if [ -f "$BITACORA" ] && [ $(wc -l < "$BITACORA") -gt 450 ]; then
        echo "  ⚠️ Backpressure: bitácora > 450 líneas. Ejecutando digest..."
        digest
    fi
    echo "  ✅ Filtro 1 PASS"

    echo "[2/5] Escaneando credenciales..."
    if grep -Eiq "(gsk_[a-zA-Z0-9]{20,}|sk-or-v1-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{36}|[0-9]{10,12}:AA[a-zA-Z0-9_-]{33})" "$TARGET"; then
        echo "❌ FAIL [F2]: Credenciales detectadas (Art. 12)."
        exit 1
    fi
    echo "  ✅ Filtro 2 PASS"

    echo "[3/5] Verificando comandos destructivos..."
    if grep -Eq "(rm -rf /|chmod 777)" "$TARGET"; then
        echo "❌ FAIL [F3]: Comandos destructivos peligrosos."
        exit 1
    fi
    if grep -Eq "^[^#]*> *SOBERANO_00_GOBIERNO/(CONSTITUCION|NORMATIVA|REGLAMENTO)" "$TARGET"; then
        echo "❌ FAIL [F3]: Intento de sobrescribir archivos inmutables."
        exit 1
    fi
    echo "  ✅ Filtro 3 PASS"

    if [ "$DRY_RUN" = true ]; then
        echo "[4/5] MODO DRY-RUN: Omitiendo ejecución real."
        ELAPSED=0
    else
        echo "[4/5] Prueba de ejecución con sandbox..."
        START_TIME=$(date +%s%N)
        TMP_LOG="/tmp/nexus_veeduria_$$.log"
        
        if [[ "$TARGET" == *.py ]]; then
            timeout 30 python3 "$TARGET" > "$TMP_LOG" 2>&1 || { 
                echo "❌ FAIL [F4]: Fallo en ejecución. Logs:"
                cat "$TMP_LOG" 2>/dev/null || true
                rm -f "$TMP_LOG"
                exit 1 
            }
        elif [[ "$TARGET" == *.sh ]]; then
            timeout 30 bash "$TARGET" > "$TMP_LOG" 2>&1 || { 
                echo "❌ FAIL [F4]: Fallo en ejecución. Logs:"
                cat "$TMP_LOG" 2>/dev/null || true
                rm -f "$TMP_LOG"
                exit 1 
            }
        fi
        
        END_TIME=$(date +%s%N)
        ELAPSED=$(( (END_TIME - START_TIME) / 1000000 ))
        rm -f "$TMP_LOG"
    fi
    echo "  ✅ Filtro 4 PASS (${ELAPSED}ms)"

    echo "[5/5] Registrando veeduría en Memoria (Art. 11)..."
    local AUDIT_FILE="SOBERANO_01_MEMORIA/AUDITS/AUDITS_${MES_ACTUAL}.md"
    mkdir -p SOBERANO_01_MEMORIA/AUDITS
    if [ ! -f "$AUDIT_FILE" ]; then
        echo -e "---\nid: AUDITS-${MES_ACTUAL}\ndate: $FECHA_SHORT\ntype: Registro_Auditoria_Mensual\n---\n# 📝 AUDITORÍAS EAD - ${MES_ACTUAL}" > "$AUDIT_FILE"
    fi

    {
        echo ""
        echo "## 🛡️ VEEDURÍA EXITOSA (PASS ✅) - $FECHA_ISO"
        echo "- **Script:** $TARGET"
        echo "- **Tiempo:** ${ELAPSED}ms"
        echo "- **Modo:** $([ "$DRY_RUN" = true ] && echo 'DRY-RUN' || echo 'REAL')"
        echo "- **Resultado:** 5/5 Filtros + Constitución Superados PASS ✅"
    } >> "$AUDIT_FILE"

    echo "[$FECHA_ISO] [VEEDURIA PASS] $TARGET superó los 5 filtros + Constitución en ${ELAPSED}ms." >> "$BITACORA"
    
    actualizar_semaforo
    
    git add SOBERANO_* .gitignore 2>/dev/null || true
    git commit -m "[VEEDURIA PASS] $TARGET verificado con 5 filtros + Constitución EAD" || true
    
    echo ""
    echo "🎉 VEEDURÍA COMPLETADA: 5/5 filtros + Constitución superados."
}

case "$COMANDO" in
    "doctor") doctor $2 ;;
    "watchdog") watchdog ;;
    "sugerir") sugerir ;;
    "salud") salud ;;
    "validar-secrets") validar_secrets ;;
    "respaldar") respaldar ;;
    "validar") validar ;;
    "auditar") auditar ;;
    "limpiar") limpiar ;;
    "digest") digest ;;
    "estado") estado ;;
    "inspeccionar") inspeccionar ;;
    "veeduria") veeduria $2 $3 ;;
    *)
        echo "🏛️ NEXUS CLI v3.0 OMNISCIENTE CONTRALOR CONSTITUCIONAL"
        echo "======================================================"
        echo "Uso: ./SOBERANO_00_GOBIERNO/nexus_cli.sh [comando]"
        echo ""
        echo "🆕 COMANDOS NUEVOS (v3.0):"
        echo "  doctor [--online]     - Diagnóstico integral + Constitución"
        echo "  watchdog              - Gestión adaptativa de recursos"
        echo "  sugerir               - Recomendaciones proactivas"
        echo "  salud                 - Resumen ejecutivo del sistema"
        echo "  validar-secrets       - Verificación de credenciales (Art. 12)"
        echo "  respaldar             - Snapshot inmutable + Tag Git"
        echo ""
        echo "📜 COMANDOS EXISTENTES (v2.1 conservados):"
        echo "  validar               - Verifica cuotas departamentales"
        echo "  auditar               - Genera reporte EAD mensual"
        echo "  limpiar               - Pulir raíz (Art. 9)"
        echo "  digest                - Rotación de bitácora"
        echo "  estado                - Foto del sistema con semáforo"
        echo "  inspeccionar          - Lectura física de SOBERANO_02_CORE"
        echo "  veeduria <script> [--dry-run] - Auditoría 5 filtros + Constitución"
        exit 1
        ;;
esac
